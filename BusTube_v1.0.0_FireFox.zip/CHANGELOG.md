CleanTube — Changelog
Historique complet du développement de l'extension.

Système de Versioning
Titre de la section : Beta Dev {MINOR} — {Nom de la fonctionnalité}

Le numéro MINOR (0.1, 0.2, 0.3...) augmente uniquement lors du passage à un nouveau bloc de fonctionnalités.

Entrée de liste : v{PATCH} — {Description}

Le numéro v (v1, v2, v3...) représente les patchs, fix et ajustements.

Important : Le compteur v repart obligatoirement à v1 au début de chaque nouvelle section MINOR.

Règle : À partir de maintenant, chaque modification du code doit donner lieu à une nouvelle entrée en haut de ce fichier.

Historique des Versions
#Beta Dev 0.5 — Panel "Custom Theme" (Light / Dark / Midnight + couleurs)#

v21 — Fix visuel des cercles de couleur dans le panel

Correction des bordures des cercles de la palette qui affichaient des coins carrés (conflit border + overflow: hidden + border-radius).

Remplacement par un anneau propre généré via box-shadow.

Passage des cercles en rendu split diagonal dark/light (couleur du mode sombre + couleur du mode clair), conforme au design visuel ciblé.

v20 — Fix barre de recherche (définitif)

Prise en compte de la nouvelle UI de recherche YouTube (.ytSearchboxComponentInputBox) qui applique son fond en dur au lieu d'utiliser une variable CSS.

Ajout du ciblage direct de cette classe pour les modes Dark et Light.

v19 — Fix mode Dark trop clair

Correction du fond des thèmes Dark qui restait par endroits plus clair que prévu sur certains conteneurs.

Élargissement des sélecteurs CSS à l'ensemble des conteneurs YouTube (#comments, sidebar, #drawer, ytd-watch-flexy, etc.).

v18 — Fix barre de recherche (1ère tentative)

La barre de recherche ne prenait pas la couleur du thème.

Ajout du ciblage des variables CSS dédiées à la searchbox.

v17 — Ajout des couleurs pastel en mode Light

Correction des thèmes colorés (Pink, Winter, Apple, Peach, Summer) qui ne s'appliquaient qu'en mode Dark.

Ajout d'une déclinaison pastel (bgLight) pour chaque couleur en mode Light.

Nettoyage d'un bloc CSS dupliqué dans le code.

v16 — Fix lisibilité en mode Light

Le menu "Custom Theme" et le bouton "Next" du carrousel devenaient illisibles (texte noir sur fond sombre) à cause d'une règle CSS globale trop large (ytd-app *).

Isolation du menu pour forcer son texte en blanc et réinitialisation des boutons/icônes natifs YouTube pour conserver leur lisibilité.

v15 — Fix crash au chargement

Correction de l'erreur Uncaught TypeError: Cannot read properties of null (reading 'insertBefore') qui survenait lorsque le script tentait d'insérer le bouton de thème avant le chargement complet du masthead YouTube.

Ajout de la garde if (!mastheadButtons) return;.

v14 — Fix versioning affiché

Correction du numéro de version affiché dans la popup d'options.

ℹ️ Note de développement : Migration du workflow de développement à partir de la version v14.

v1 à v13 — Développement initial du panel de thèmes

Création du bouton "Change theme" et du menu déroulant dans le masthead YouTube (icône lune à côté de "Create").

Passage d'un interrupteur simple à 3 modes : Light, Dark, et Midnight (fond OLED #000000).

Ajout de la palette de couleurs : Normal, Pink, Winter, Apple, Peach, Summer avec cercles bicolores.

Implémentation du mode Light natif YouTube :

Suppression/ajout dynamique de l'attribut dark sur html/body/ytd-app.

Forçage de la couleur du texte et de la typographie.

Prise en charge des évolutions de la barre de recherche YouTube (intégration des sélecteurs .sbdd_b, .sbsb_a, yt-searchbox, .ytSearchboxComponentInputBox).

Correctif appliqué aux boutons de navigation et filtres sombres (.yt-spec-button-shape-next--tonal, #left-arrow-button, #right-arrow-button).

Gestion de la couleur adaptative du bouton "Change theme" selon le mode actif.

Sécurisation de l'injection du bouton lors de la navigation SPA (Single Page Application) de YouTube.

Beta Dev 0.4 — Panel d'options (Popup + Toggles + Timeline)
v9 — Fix définitif transparence timeline

Correction des différences d'opacité entre la bille et la barre (superposition de transparences sur les éléments enfants).

Application d'un fond unique sur .ytp-play-progress, passage des enfants en rendu transparent, et nettoyage du rail .ytp-progress-list.

v8 — Fix rendu translucide

Le buffer gris de YouTube (.ytp-load-progress) restait visible sous la barre translucide et écrasait l'effet.

Correction du point de lecture qui devenait un cercle fantôme à faible opacité.

Séparation de l'ajustement couleur entre le curseur (scrubber) et la barre progression.

v7 — Correction couleur complète de la barre

Prise en compte du dégradé rouge interne de YouTube qui empêchait la couleur personnalisée de s'appliquer sur toute la barre.

Élargissement du ciblage CSS (*, ::before, ::after) et surcharge de --yt-spec-static-brand-red.

v6 — Suppression du dégradé natif

Ajout de background-image: none pour neutraliser le dégradé rouge natif de la barre de lecture.

v5 — Ajustement opacité "Translucent"

Réglage de l'opacité passée de 0.35 à 0.18 pour éviter un rendu trop sombre/gris.

v4 — Fix suppression Shorts dans la sidebar

Le bouton Shorts restait visible dans la barre latérale (états replié et déplié) malgré l'option désactivée.

Élargissement des sélecteurs CSS sur les éléments contenant href*="shorts" et title*="Shorts" dans le menu principal et le mini-guide.

v3 — Stabilisation des fonctionnalités du panel

Correction de la couleur de timeline qui était écrasée par le style inline réécrit par YouTube.

Correction des toggles Dislikes/Shorts qui s'appliquaient avant l'existence du body.

Correction du compteur de dislikes qui ne s'incrémentait pas au clic.

Passage à un système d'injection dynamique de balises <style> et mise en cache mémoire (currentDislikeText, currentRawCount) pour persister durant la navigation SPA.

v2 — Correctifs UI Popup

Correction du fond de thème qui ne s'appliquait pas.

Correction d'une erreur de balisage HTML dans popup.html.

v1 — Création du panel popup

Création de la structure du popup (popup.html, popup.css, popup.js).

Intégration des toggles : Disable YouTube Shorts et Activate YouTube Dislike.

Ajout de la grille de couleurs pour la timeline (rouge, vert, bleu, blanc, noir, turquoise, jaune, vert pomme, translucide).

Sauvegarde des préférences via chrome.storage.local et synchronisation en direct avec content.js.

Beta Dev 0.3 — Dislikes (Stabilisation)
v1 — Intégration et fiabilité de l'API Return YouTube Dislike

Ajout du compteur basé sur l'API externe.

Prise en charge du nouveau sélecteur du bouton dislike (dislike-button-view-model).

Optimisation des vérifications : passage d'un intervalle de 500ms à une vérification immédiate suivie d'un polling court.

Correction des débordements visuels du texte hors du bouton (width: auto, max-width: none).

Prise en compte de la navigation SPA pour mettre à jour le compteur sans rechargement de page (F5).

Gestion du clic utilisateur avec estimation instantanée (+1/-1).

Mise en place d'un cache global et d'un cycle de vérification continu (setInterval à 300ms) pour maintenir l'affichage si YouTube re-crée le bouton au vol.

Beta Dev 0.2 — Suppression des Shorts (Sidebar)
v1 — Masquage sidebar & ajustement manifest

Renforcement du ciblage CSS pour masquer l'onglet Shorts dans les deux états de la barre latérale (déployée et réduite).

Correction de la structure JSON du manifest (utilisation de version_name pour afficher la mention "Beta Dev 0.2 v1").

Beta Dev 0.1 — Suppression des Shorts (Base)
v1 — Initialisation du projet

Initialisation du projet CleanTube (Manifest V3).

Masquage CSS des Shorts sur la page d'accueil, les abonnements, la recherche et les suggestions.

Mise en place de la redirection automatique /shorts/{id} vers /watch?v={id} en cas d'accès direct.