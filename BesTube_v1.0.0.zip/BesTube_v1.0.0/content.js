// =========================================================
// VARIABLES GLOBALES
// =========================================================
let currentVideoId = '';
let currentDislikeText = '';
let currentRawCount = 0;

let settings = {
  hideShorts: true,
  showDislikes: true,
  timelineColor: '#ff0000',
  customTheme: 'normal',
  themeMode: 'dark' // 'light', 'dark', ou 'midnight'
};

// =========================================================
// 1. TIMELINE & SHORTS DYNAMIQUES
// =========================================================

// Force la couleur sur la barre rouge + le point de lecture
function applyTimelineColor(color) {
  let styleTag = document.getElementById('cleantube-timeline-style');
  if (!styleTag) {
    styleTag = document.createElement('style');
    styleTag.id = 'cleantube-timeline-style';
    (document.head || document.documentElement).appendChild(styleTag);
  }

  const isTranslucent = color.includes('rgba');

  styleTag.textContent = `
    :root, html, body, #movie_player, .html5-video-player, ytd-player {
      --ytp-swatch-primary: ${color} !important;
      --ytp-swatch-primary-color: ${color} !important;
      --yt-spec-static-brand-red: ${color} !important;
    }

    /* Barre de lecture principale (fond unique pour éviter de superposer les opacités) */
    .ytp-play-progress,
    .ytp-play-progress.ytp-swatch-bg {
      background: ${color} !important;
      background-color: ${color} !important;
      background-image: none !important;
    }

    /* Désactive le fond des enfants pour ne pas doubler/tripler la transparence */
    .ytp-play-progress * {
      background: transparent !important;
      background-color: transparent !important;
    }

    /* Nettoie le rail global et le buffer en dessous si translucide */
    ${isTranslucent ? `
    .ytp-progress-list,
    .ytp-load-progress {
      background: rgba(255, 255, 255, 0.05) !important;
    }
    ` : ''}

    /* Point de lecture (la bille) */
    .ytp-scrubber-button,
    .ytp-scrubber-button.ytp-swatch-background-color {
      background: ${color} !important;
      background-color: ${color} !important;
      box-shadow: none !important;
      opacity: 1 !important;
    }

    .ytp-scrubber-button * {
      background: transparent !important;
    }

    .ytp-hover-progress-light {
      background: ${color} !important;
    }
  `;
}

// Masque / Affiche les Shorts dynamiquement
function applyShortsVisibility(hideShorts) {
  let styleTag = document.getElementById('cleantube-shorts-style');
  if (hideShorts) {
    if (!styleTag) {
      styleTag = document.createElement('style');
      styleTag.id = 'cleantube-shorts-style';
      styleTag.textContent = `
        ytd-guide-entry-renderer:has(a[href*="shorts"]),
        ytd-guide-entry-renderer:has(a[title*="Shorts"]),
        ytd-guide-entry-renderer:has(a[title*="shorts"]),
        ytd-mini-guide-entry-renderer:has(a[href*="shorts"]),
        ytd-mini-guide-entry-renderer:has(a[title*="Shorts"]),
        ytd-mini-guide-entry-renderer:has(a[title*="shorts"]),
        ytd-rich-section-renderer:has(a[href*="shorts"]),
        ytd-reel-shelf-renderer,
        ytd-rich-shelf-renderer[is-shorts],
        yt-tab-shape:has(a[href*="shorts"]),
        ytd-compact-video-renderer:has(a[href*="shorts"]) {
          display: none !important;
        }
      `;
      (document.head || document.documentElement).appendChild(styleTag);
    }
  } else {
    if (styleTag) {
      styleTag.remove();
    }
  }
}

// Application du thème Midnight et des teintes personnalisées
// Application des modes (Light / Dark / Midnight) et des teintes

function applyCustomTheme(theme, mode) {
  const html = document.documentElement;
  const body = document.body;
  const ytdApp = document.querySelector('ytd-app');

  // 1. Bascule des attributs HTML
  if (mode === 'light') {
    html.removeAttribute('dark');
    if (body) body.removeAttribute('dark');
    if (ytdApp) ytdApp.removeAttribute('dark');
    html.style.colorScheme = 'light';
  } else {
    html.setAttribute('dark', 'true');
    if (body) body.setAttribute('dark', 'true');
    if (ytdApp) ytdApp.setAttribute('dark', 'true');
    html.style.colorScheme = 'dark';
  }

  // 2. Ajustement du bouton "Change theme"
  const themeBtn = document.getElementById('cleantube-theme-btn');
  if (themeBtn) {
    if (mode === 'light') {
      themeBtn.style.color = '#0f0f0f';
      themeBtn.style.background = 'rgba(0, 0, 0, 0.08)';
    } else {
      themeBtn.style.color = '#ffffff';
      themeBtn.style.background = 'rgba(255, 255, 255, 0.1)';
    }
  }

  // 3. Application forcée des couleurs CSS (Light, Dark, Midnight)
  let styleTag = document.getElementById('cleantube-theme-style');
  if (!styleTag) {
    styleTag = document.createElement('style');
    styleTag.id = 'cleantube-theme-style';
    (document.head || document.documentElement).appendChild(styleTag);
  }

let css = '';

  if (mode === 'light') {
    css += `
      html, body, ytd-app, #page-manager, ytd-masthead, #chips-wrapper, #content, #guide-content, ytd-mini-guide-renderer, yt-searchbox {
        --yt-spec-base-background: #ffffff !important;
        --yt-spec-raised-background: #ffffff !important;
        --yt-spec-menu-background: #ffffff !important;
        --yt-spec-general-background-a: #ffffff !important;
        --yt-spec-general-background-b: #ffffff !important;
        --yt-spec-general-background-c: #ffffff !important;
        --yt-spec-text-primary: #000000 !important;
        --yt-spec-text-secondary: #333333 !important;
        --ytd-searchbox-background: #ffffff !important;
        --ytd-searchbox-text-color: #000000 !important;
        background-color: #ffffff !important;
      }
      ytd-app *, yt-formatted-string, #video-title, span, a, h1, h2, h3, p, input {
        color: #000000 !important;
      }
      ytd-searchbox, ytd-searchbox #container, ytd-searchbox input, #container.ytd-searchbox,
      yt-searchbox, .ytSearchboxComponentInputBox, .ytSearchboxComponentSuggestionsContainer,
      .ytSearchboxComponentSuggestionsContainer *, .sbdd_b, .sbsb_a, .sbfl_b {
        background-color: #ffffff !important;
        background: #ffffff !important;
        color: #000000 !important;
      }
      .sbqs_c, .gsfs, .sbsb_c, .sbpqs_a, .ytSearchboxComponentSuggestion { color: #000000 !important; }
      .sbsb_d, .ytSearchboxComponentSuggestion:hover { background-color: #f2f2f2 !important; }
      ytd-searchbox input::placeholder, yt-searchbox input::placeholder { color: #606060 !important; }

      /* Le menu Custom Theme garde toujours un fond sombre : on force le texte en blanc */
      #cleantube-theme-menu, #cleantube-theme-menu * {
        color: #ffffff !important;
      }

      /* On laisse YouTube gérer nativement la couleur de ses propres boutons/icônes
         (carrousel, contrôles) au lieu de forcer du noir dessus */
      button, button *, yt-icon-button, yt-icon-button *,
      tp-yt-paper-icon-button, tp-yt-paper-icon-button *,
      .ytp-button, .ytp-button * {
        color: unset !important;
      }
    `;
  }

  if (mode === 'midnight') {
    css += `
      html[dark], [dark], ytd-app, body, #page-manager, ytd-masthead, #chips-wrapper, #content, #guide-content, ytd-mini-guide-renderer {
        --yt-spec-base-background: #000000 !important;
        --yt-spec-raised-background: #050505 !important;
        --yt-spec-menu-background: #0a0a0a !important;
        --yt-spec-general-background-a: #000000 !important;
        --yt-spec-general-background-b: #050505 !important;
        --yt-spec-general-background-c: #0a0a0a !important;
        --ytd-searchbox-background: #000000 !important;
        background-color: #000000 !important;
      }
    `;
  }

  // Palette d'accents + fond associé (uniquement actif en mode Dark)
const themePresets = {
    pink:   { accent: '#ff80df', bg: '#2d002b', bgLight: '#fde6f9' },
    winter: { accent: '#70a1ff', bg: '#050520', bgLight: '#e8f0ff' },
    apple:  { accent: '#7bed9f', bg: '#051f05', bgLight: '#e6fbec' },
    peach:  { accent: '#ff7675', bg: '#2b0505', bgLight: '#ffe9e8' },
    summer: { accent: '#ffeaa7', bg: '#1f1f05', bgLight: '#fff8e1' }
  };

 if (theme && themePresets[theme]) {
    const t = themePresets[theme];

    if (mode === 'dark') {
      css += `
        html[dark], [dark], ytd-app, body,
        #page-manager, ytd-masthead, #chips-wrapper, #content, #guide-content, ytd-mini-guide-renderer,
        ytd-searchbox, ytd-searchbox #container, #container.ytd-searchbox, yt-searchbox,
        ytd-watch-flexy, #primary, #secondary, #columns, #primary-inner, #secondary-inner,
        ytd-comments, #comments, ytd-item-section-renderer,
        tp-yt-app-drawer, #guide-inner-content, ytd-guide-renderer,
        ytd-video-primary-info-renderer, ytd-video-secondary-info-renderer,
        ytd-browse, ytd-two-column-browse-results-renderer, ytd-section-list-renderer,
        ytd-browse-header-renderer, ytd-c4-tabbed-header-renderer, #page-header,
        tp-yt-paper-tabs, tp-yt-tab, yt-tab-shape, #tabsContent,
        ytd-feed-filter-chip-bar-renderer, iron-selector,
        #below, #panels {
          --yt-spec-base-background: ${t.bg} !important;
          --yt-spec-raised-background: ${t.bg} !important;
          --yt-spec-menu-background: ${t.bg} !important;
          --yt-spec-general-background-a: ${t.bg} !important;
          --yt-spec-general-background-b: ${t.bg} !important;
          --yt-spec-general-background-c: ${t.bg} !important;
          --ytd-searchbox-background: ${t.bg} !important;
          --yt-spec-brand-background-solid: ${t.bg} !important;
          --yt-spec-brand-background-primary: ${t.bg} !important;
          background-color: ${t.bg} !important;
        }
      `;
      css += `
        ytd-searchbox #container, #container.ytd-searchbox,
        .ytSearchboxComponentInputBox, .ytSearchboxComponentSuggestionsContainer {
          background-color: ${t.bg} !important;
          background: ${t.bg} !important;
        }
      `;
      // Zones encore noires malgré les variables ci-dessus : chips/dropdowns,
      // cartes promo (Premium), sidebar repliée (mini guide) et barre d'onglets de chaîne.
      css += `
        html[dark], [dark], ytd-app, body {
          --yt-spec-badge-chip-background: ${t.bg} !important;
          --yt-spec-10-percent-layer: ${t.bg} !important;
          --yt-spec-static-overlay-background-solid: ${t.bg} !important;
          --yt-spec-static-overlay-background: ${t.bg} !important;
        }
        ytd-primetime-promo-renderer, ytd-statement-banner-renderer, ytd-message-renderer,
        ytd-brand-video-shelf-renderer, ytd-panel-renderer,
        chip-bar-view-model, .ytChipBarViewModelHost,
        tp-yt-paper-button, ytd-sort-filter-sub-menu-renderer, yt-sort-filter-sub-menu-renderer,
        tp-yt-iron-dropdown, tp-yt-paper-listbox, ytd-menu-popup-renderer,
        ytd-playlist-header-renderer, ytd-playlist-sidebar-renderer,
        #guide, tp-yt-app-drawer, tp-yt-app-drawer#guide,
        ytd-guide-renderer, ytd-guide-entry-renderer, ytd-mini-guide-entry-renderer,
        #tabsContainer, yt-tab-group-shape, tp-yt-paper-tab,
        ytd-tabbed-page-header, #page-header-container.ytd-tabbed-page-header,
        #page-header-banner.ytd-tabbed-page-header, tp-yt-app-header,
        tp-yt-app-header #background, tp-yt-app-header #contentContainer {
          background-color: ${t.bg} !important;
          background: ${t.bg} !important;
        }
        /* Chips de filtres (Tout, Musique, Direct...) : on ne les force PAS à la couleur
           du fond de page (sinon elles deviennent invisibles, fondues dans le fond).
           On leur donne un fond translucide clair pour qu'elles restent visibles
           quelle que soit la couleur du thème choisi. */
        yt-chip-cloud-renderer {
          background-color: transparent !important;
          background: transparent !important;
        }
        yt-chip-cloud-chip-renderer:not([selected]) {
          background-color: rgba(255, 255, 255, 0.12) !important;
          background: rgba(255, 255, 255, 0.12) !important;
          border-radius: 999px !important;
          overflow: hidden !important;
        }
        yt-chip-cloud-chip-renderer:not([selected]) * {
          background-color: transparent !important;
          background: transparent !important;
        }
        /* La carte Premium fixe sa couleur en style inline : on doit forcer par-dessus */
        ytd-statement-banner-renderer #background-content,
        ytd-statement-banner-renderer #foreground-content,
        div#background-content.ytd-statement-banner-renderer,
        div#foreground-content.ytd-statement-banner-renderer {
          background-color: ${t.bg} !important;
        }
        /* Ces divs internes utilisent le nom du composant comme CLASSE (shady CSS),
           pas comme balise : il faut cibler ".nom-du-composant", pas "nom-du-composant".
           Leur background-color vient d'une variable générée dynamiquement par YouTube
           (hash aléatoire ou couleur extraite de la bannière) qu'on ne peut pas viser
           par nom : on écrase donc directement la propriété avec !important. */
        #header.style-scope.ytd-item-section-renderer,
        .ytd-item-section-renderer#header,
        #tabs-inner-container.style-scope.ytd-tabbed-page-header,
        .ytd-tabbed-page-header#tabs-inner-container,
        #tabs-container.style-scope.ytd-tabbed-page-header,
        .ytd-tabbed-page-header#tabs-container {
          background-color: ${t.bg} !important;
          background: ${t.bg} !important;
        }
      `;
    }

    if (mode === 'light') {
      css += `
        html, body, ytd-app, #page-manager, ytd-masthead, #chips-wrapper, #content, #guide-content, ytd-mini-guide-renderer,
        ytd-searchbox, ytd-searchbox #container, #container.ytd-searchbox, yt-searchbox {
          --yt-spec-base-background: ${t.bgLight} !important;
          --yt-spec-raised-background: ${t.bgLight} !important;
          --yt-spec-menu-background: ${t.bgLight} !important;
          --yt-spec-general-background-a: ${t.bgLight} !important;
          --yt-spec-general-background-b: ${t.bgLight} !important;
          --yt-spec-general-background-c: ${t.bgLight} !important;
          --ytd-searchbox-background: ${t.bgLight} !important;
          background-color: ${t.bgLight} !important;
        }
      `;
      css += `
        ytd-searchbox #container, #container.ytd-searchbox,
        .ytSearchboxComponentInputBox, .ytSearchboxComponentSuggestionsContainer {
          background-color: ${t.bgLight} !important;
          background: ${t.bgLight} !important;
        }
      `;
      css += `
        html, body, ytd-app {
          --yt-spec-badge-chip-background: ${t.bgLight} !important;
          --yt-spec-10-percent-layer: ${t.bgLight} !important;
          --yt-spec-static-overlay-background-solid: ${t.bgLight} !important;
          --yt-spec-static-overlay-background: ${t.bgLight} !important;
        }
        ytd-primetime-promo-renderer, ytd-statement-banner-renderer, ytd-message-renderer,
        ytd-brand-video-shelf-renderer, ytd-panel-renderer,
        chip-bar-view-model, .ytChipBarViewModelHost,
        tp-yt-paper-button, ytd-sort-filter-sub-menu-renderer, yt-sort-filter-sub-menu-renderer,
        tp-yt-iron-dropdown, tp-yt-paper-listbox, ytd-menu-popup-renderer,
        ytd-playlist-header-renderer, ytd-playlist-sidebar-renderer,
        #guide, tp-yt-app-drawer, tp-yt-app-drawer#guide,
        ytd-guide-renderer, ytd-guide-entry-renderer, ytd-mini-guide-entry-renderer,
        #tabsContainer, yt-tab-group-shape, tp-yt-paper-tab,
        ytd-tabbed-page-header, #page-header-container.ytd-tabbed-page-header,
        #page-header-banner.ytd-tabbed-page-header, tp-yt-app-header,
        tp-yt-app-header #background, tp-yt-app-header #contentContainer {
          background-color: ${t.bgLight} !important;
          background: ${t.bgLight} !important;
        }
        /* Chips de filtres : meme logique qu'en mode dark, fond distinct pour rester visibles */
        yt-chip-cloud-renderer {
          background-color: transparent !important;
          background: transparent !important;
        }
        yt-chip-cloud-chip-renderer:not([selected]) {
          background-color: rgba(0, 0, 0, 0.08) !important;
          background: rgba(0, 0, 0, 0.08) !important;
          border-radius: 999px !important;
          overflow: hidden !important;
        }
        yt-chip-cloud-chip-renderer:not([selected]) * {
          background-color: transparent !important;
          background: transparent !important;
        }
        ytd-statement-banner-renderer #background-content,
        ytd-statement-banner-renderer #foreground-content,
        div#background-content.ytd-statement-banner-renderer,
        div#foreground-content.ytd-statement-banner-renderer {
          background-color: ${t.bgLight} !important;
        }
        #header.style-scope.ytd-item-section-renderer,
        .ytd-item-section-renderer#header,
        #tabs-inner-container.style-scope.ytd-tabbed-page-header,
        .ytd-tabbed-page-header#tabs-inner-container,
        #tabs-container.style-scope.ytd-tabbed-page-header,
        .ytd-tabbed-page-header#tabs-container {
          background-color: ${t.bgLight} !important;
          background: ${t.bgLight} !important;
        }
      `;
    }

    css += `
      :root, html, body {
        --yt-spec-themed-blue: ${t.accent} !important;
        --yt-spec-call-to-action: ${t.accent} !important;
      }
      yt-chip-cloud-chip-renderer[selected] {
        background-color: ${t.accent} !important;
        color: #000000 !important;
        border-radius: 999px !important;
        overflow: hidden !important;
      }
      yt-chip-cloud-chip-renderer[selected] * {
        background-color: transparent !important;
        background: transparent !important;
      }
      #like-button button[aria-pressed="true"] {
        color: ${t.accent} !important;
      }
    `;
  }

  styleTag.textContent = css;
}


// Injection du bouton "Change theme" et de son menu déroulant
// Injection du bouton "Change theme" avec la Lune et du menu
function injectThemeMenuButton() {
  const mastheadButtons = document.querySelector('#buttons.ytd-masthead, #end #buttons');

  // Si le masthead n'est pas encore chargé, on quitte et on réessaiera au prochain cycle
  if (!mastheadButtons) return;

  const existingWrapper = document.getElementById('cleantube-theme-wrapper');
  if (existingWrapper && document.body.contains(existingWrapper)) return;
  if (existingWrapper) existingWrapper.remove();

  const wrapper = document.createElement('div');
  wrapper.id = 'cleantube-theme-wrapper';
  wrapper.style.cssText = `
    position: relative;
    display: inline-flex;
    align-items: center;
    margin-right: 8px;
    font-family: "Roboto", "Arial", sans-serif;
  `;

  wrapper.innerHTML = `
    <!-- Bouton principal avec la LUNE -->
    <button id="cleantube-theme-btn" style="
      display: flex;
      align-items: center;
      gap: 6px;
      background: rgba(255, 255, 255, 0.1);
      border: none;
      color: #fff;
      padding: 0 14px;
      height: 36px;
      border-radius: 18px;
      cursor: pointer;
      font-size: 14px;
      font-weight: 500;
      transition: background 0.2s;
    ">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12.3 2a10 10 0 0 0 9.7 12.8 10 10 0 1 1-9.7-12.8z"/>
      </svg>
      <span>Change theme</span>
    </button>

    <!-- Menu déroulant -->
    <div id="cleantube-theme-menu" style="
      display: none;
      position: absolute;
      top: 46px;
      right: 0;
      background: #1f1f1f;
      border: 1px solid #333;
      border-radius: 16px;
      padding: 16px;
      width: 290px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.6);
      z-index: 999999;
      color: #fff;
      box-sizing: border-box;
    ">
      <span style="font-size: 14px; font-weight: 600; display: block; margin-bottom: 10px;">Custom Theme</span>

      <!-- 3 Petits Boutons de Mode : Light / Dark / Midnight -->
      <div style="display: flex; background: #121212; border-radius: 8px; padding: 3px; gap: 4px; margin-bottom: 16px;">
        <button class="ct-mode-btn ${settings.themeMode === 'light' ? 'active' : ''}" data-mode="light" style="
          flex: 1; border: none; padding: 6px 0; border-radius: 6px; font-size: 11px; font-weight: 600; cursor: pointer;
          background: ${settings.themeMode === 'light' ? '#333' : 'transparent'}; color: ${settings.themeMode === 'light' ? '#fff' : '#aaa'};
        ">Light</button>

        <button class="ct-mode-btn ${settings.themeMode === 'dark' ? 'active' : ''}" data-mode="dark" style="
          flex: 1; border: none; padding: 6px 0; border-radius: 6px; font-size: 11px; font-weight: 600; cursor: pointer;
          background: ${settings.themeMode === 'dark' ? '#333' : 'transparent'}; color: ${settings.themeMode === 'dark' ? '#fff' : '#aaa'};
        ">Dark</button>

        <button class="ct-mode-btn ${settings.themeMode === 'midnight' ? 'active' : ''}" data-mode="midnight" style="
          flex: 1; border: none; padding: 6px 0; border-radius: 6px; font-size: 11px; font-weight: 600; cursor: pointer;
          background: ${settings.themeMode === 'midnight' ? '#333' : 'transparent'}; color: ${settings.themeMode === 'midnight' ? '#fff' : '#aaa'};
        ">Midnight</button>
      </div>

     <!-- Palette de couleurs -->
      <div style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 6px; text-align: center; margin-bottom: 14px; align-items: start;">

        <!-- Normal -->
        <div class="ct-palette-item" data-theme="normal" style="cursor: pointer;">
          <div style="width: 32px; height: 32px; border-radius: 50%; overflow: hidden; background: linear-gradient(135deg, #0f0f0f 50%, #ffffff 50%); margin: 0 auto; box-shadow: 0 0 0 2px ${settings.customTheme === 'normal' ? '#fff' : 'transparent'};"></div>
          <span style="font-size: 10px; display: block; margin-top: 4px; color: #ccc;">Normal</span>
        </div>

        <!-- Pink -->
        <div class="ct-palette-item" data-theme="pink" style="cursor: pointer;">
          <div style="width: 32px; height: 32px; border-radius: 50%; overflow: hidden; background: linear-gradient(135deg, #2d002b 50%, #fde6f9 50%); margin: 0 auto; box-shadow: 0 0 0 2px ${settings.customTheme === 'pink' ? '#fff' : 'transparent'};"></div>
          <span style="font-size: 10px; display: block; margin-top: 4px; color: #ccc;">Pink</span>
        </div>

        <!-- Winter -->
        <div class="ct-palette-item" data-theme="winter" style="cursor: pointer;">
          <div style="width: 32px; height: 32px; border-radius: 50%; overflow: hidden; background: linear-gradient(135deg, #050520 50%, #e8f0ff 50%); margin: 0 auto; box-shadow: 0 0 0 2px ${settings.customTheme === 'winter' ? '#fff' : 'transparent'};"></div>
          <span style="font-size: 10px; display: block; margin-top: 4px; color: #ccc;">Winter</span>
        </div>

        <!-- Apple -->
        <div class="ct-palette-item" data-theme="apple" style="cursor: pointer;">
          <div style="width: 32px; height: 32px; border-radius: 50%; overflow: hidden; background: linear-gradient(135deg, #051f05 50%, #e6fbec 50%); margin: 0 auto; box-shadow: 0 0 0 2px ${settings.customTheme === 'apple' ? '#fff' : 'transparent'};"></div>
          <span style="font-size: 10px; display: block; margin-top: 4px; color: #ccc;">Apple</span>
        </div>

        <!-- Peach -->
        <div class="ct-palette-item" data-theme="peach" style="cursor: pointer;">
          <div style="width: 32px; height: 32px; border-radius: 50%; overflow: hidden; background: linear-gradient(135deg, #2b0505 50%, #ffe9e8 50%); margin: 0 auto; box-shadow: 0 0 0 2px ${settings.customTheme === 'peach' ? '#fff' : 'transparent'};"></div>
          <span style="font-size: 10px; display: block; margin-top: 4px; color: #ccc;">Peach</span>
        </div>

        <!-- Summer -->
        <div class="ct-palette-item" data-theme="summer" style="cursor: pointer;">
          <div style="width: 32px; height: 32px; border-radius: 50%; overflow: hidden; background: linear-gradient(135deg, #1f1f05 50%, #fff8e1 50%); margin: 0 auto; box-shadow: 0 0 0 2px ${settings.customTheme === 'summer' ? '#fff' : 'transparent'};"></div>
          <span style="font-size: 10px; display: block; margin-top: 4px; color: #ccc;">Summer</span>
        </div>

      </div>

      <!-- Emplacement réservé (Cercle vierge) -->
      <div style="display: flex; gap: 8px;">
        <div style="width: 32px; height: 32px; border-radius: 50%; border: 2px solid #555; background: transparent; box-sizing: border-box;"></div>
      </div>
    </div>
  `;

  mastheadButtons.insertBefore(wrapper, mastheadButtons.firstChild);

  const btn = document.getElementById('cleantube-theme-btn');
  const menu = document.getElementById('cleantube-theme-menu');

  // Clic sur le bouton principal
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
  });

  document.addEventListener('click', (e) => {
    if (!wrapper.contains(e.target)) {
      menu.style.display = 'none';
    }
  });

  // Gestion des 3 boutons de mode (Light / Dark / Midnight)
  const modeBtns = menu.querySelectorAll('.ct-mode-btn');
  modeBtns.forEach(mBtn => {
    mBtn.addEventListener('click', () => {
      const selectedMode = mBtn.dataset.mode;
      settings.themeMode = selectedMode;
      chrome.storage.local.set({ themeMode: selectedMode });

      modeBtns.forEach(b => {
        const isActive = b.dataset.mode === selectedMode;
        b.style.background = isActive ? '#333' : 'transparent';
        b.style.color = isActive ? '#fff' : '#aaa';
      });

      applyCustomTheme(settings.customTheme, settings.themeMode);
    });
  });

  // Gestion de la sélection des couleurs
  const items = menu.querySelectorAll('.ct-palette-item');
  items.forEach(item => {
    item.addEventListener('click', () => {
      const selectedTheme = item.dataset.theme;
      settings.customTheme = selectedTheme;
      chrome.storage.local.set({ customTheme: selectedTheme });

      items.forEach(i => {
        const circle = i.querySelector('div');
        circle.style.borderColor = (i.dataset.theme === selectedTheme) ? '#fff' : 'transparent';
      });

      applyCustomTheme(settings.customTheme, settings.themeMode);
    });
  });
}

function loadAndApplySettings() {
  chrome.storage.local.get({
    hideShorts: true,
    showDislikes: true,
    timelineColor: '#ff0000',
    customTheme: 'normal',
    themeMode: 'dark'
  }, (res) => {
    settings = res;
    applyTimelineColor(settings.timelineColor);
    applyShortsVisibility(settings.hideShorts);
    applyCustomTheme(settings.customTheme, settings.themeMode);

    if (!settings.showDislikes) {
      const textDiv = document.querySelector('.cleantube-dislike-text');
      if (textDiv) textDiv.remove();
    }
  });
}

chrome.storage.onChanged.addListener((changes) => {
  for (let [key, { newValue }] of Object.entries(changes)) {
    settings[key] = newValue;
  }
  applyTimelineColor(settings.timelineColor);
  applyShortsVisibility(settings.hideShorts);
  applyCustomTheme(settings.customTheme, settings.themeMode);

  if (!settings.showDislikes) {
    const textDiv = document.querySelector('.cleantube-dislike-text');
    if (textDiv) textDiv.remove();
  } else {
    updateDislikeUI();
  }
});

// =========================================================
// 2. REDIRECTION SHORTS
// =========================================================
function redirectShortsToNormalPlayer() {
  if (settings.hideShorts && window.location.pathname.startsWith('/shorts/')) {
    const videoId = window.location.pathname.split('/shorts/')[1]?.split('?')[0];
    if (videoId) {
      window.location.replace(`https://www.youtube.com/watch?v=${videoId}`);
    }
  }
}

// =========================================================
// 3. LOGIQUE DISLIKES (AVEC ÉCOUTEUR CLIC RE-CORRIGÉ)
// =========================================================
function formatCount(num) {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'k';
  return num.toLocaleString();
}

async function fetchDislikes(videoId) {
  try {
    const response = await fetch(`https://returnyoutubedislikeapi.com/votes?videoId=${videoId}`);
    if (!response.ok) return;

    const data = await response.json();

    if (data && typeof data.dislikes === 'number' && videoId === currentVideoId) {
      currentDislikeText = formatCount(data.dislikes);
      currentRawCount = data.dislikes;
      updateDislikeUI();
    }
  } catch (error) {
    console.error('CleanTube: Erreur API Dislikes', error);
  }
}

function updateDislikeUI() {
  if (!settings.showDislikes || !currentDislikeText || window.location.pathname !== '/watch') return;

  const dislikeBtn = document.querySelector(
    'dislike-button-view-model button, #segmented-dislike-button button, #dislike-button button'
  );

  if (dislikeBtn) {
    let textDiv = dislikeBtn.querySelector('.cleantube-dislike-text');

    if (!textDiv) {
      textDiv = document.createElement('div');
      textDiv.className = 'yt-spec-button-shape-next__button-text-content cleantube-dislike-text';
      textDiv.style.marginLeft = '6px';
      dislikeBtn.appendChild(textDiv);
    }

    if (textDiv.textContent !== currentDislikeText) {
      textDiv.textContent = currentDislikeText;
    }

    // Ré-injection de la réaction au clic (+1 / -1 instantané)
    if (!dislikeBtn.dataset.hasCleanTubeListener) {
      dislikeBtn.dataset.hasCleanTubeListener = 'true';
      dislikeBtn.addEventListener('click', () => {
        setTimeout(() => {
          const isPressed = dislikeBtn.getAttribute('aria-pressed') === 'true' || 
                            dislikeBtn.querySelector('button[aria-pressed="true"]');
          let updatedCount = isPressed ? currentRawCount + 1 : currentRawCount;
          currentDislikeText = formatCount(updatedCount);
          textDiv.textContent = currentDislikeText;
        }, 100);
      });
    }
  }
}

// =========================================================
// 4. BOUCLE PRINCIPALE
// =========================================================
function masterLoop() {
  redirectShortsToNormalPlayer();
  injectThemeMenuButton();

  if (window.location.pathname === '/watch') {
    const urlParams = new URLSearchParams(window.location.search);
    const videoId = urlParams.get('v');

    if (videoId) {
      if (videoId !== currentVideoId) {
        currentVideoId = videoId;
        currentDislikeText = '';
        currentRawCount = 0;
        if (settings.showDislikes) fetchDislikes(videoId);
      } else {
        updateDislikeUI();
      }
    }
  } else {
    currentVideoId = '';
    currentDislikeText = '';
  }
}

loadAndApplySettings();
setInterval(masterLoop, 300);
window.addEventListener('yt-navigate-finish', masterLoop);