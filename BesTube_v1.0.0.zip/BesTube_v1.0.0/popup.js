document.addEventListener('DOMContentLoaded', () => {
  const toggleShorts = document.getElementById('toggle-shorts');
  const toggleDislikes = document.getElementById('toggle-dislikes');
  const colorItems = document.querySelectorAll('.color-item');

  // Charge les paramètres enregistrés
  chrome.storage.local.get(
    { hideShorts: true, showDislikes: true, timelineColor: '#ff0000' },
    (settings) => {
      toggleShorts.checked = settings.hideShorts;
      toggleDislikes.checked = settings.showDislikes;
      updateActiveColorUI(settings.timelineColor);
    }
  );

  // Événements Toggles
  toggleShorts.addEventListener('change', () => {
    chrome.storage.local.set({ hideShorts: toggleShorts.checked });
  });

  toggleDislikes.addEventListener('change', () => {
    chrome.storage.local.set({ showDislikes: toggleDislikes.checked });
  });

  // Événements Couleur Timeline
  colorItems.forEach(item => {
    item.addEventListener('click', () => {
      const selectedColor = item.getAttribute('data-color');
      chrome.storage.local.set({ timelineColor: selectedColor });
      updateActiveColorUI(selectedColor);
    });
  });

  function updateActiveColorUI(activeColor) {
    colorItems.forEach(item => {
      if (item.getAttribute('data-color') === activeColor) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });
  }
});